package chap15.p801;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity extends Activity {
    private EditText txtSearch;
    private Button btnSearch;
    private EditText txtBookName, txtBookPublisher, txtBookPrice, txtBookAuthor;
    private ImageView imgBook;
    private Button btnPrev, btnNext;
    private List<Book> list = new ArrayList<Book>();
    private int currentIndex;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        getTxtSearch();
        getBtnSearch();
        getTxtBookName();
        getTxtBookPublisher();
        getTxtBookPrice();
        getTxtBookAuthor();
        getImgBook();
        getBtnPrev();
        getBtnNext();
    }


	public EditText getTxtSearch() {
		if(txtSearch == null) {
			txtSearch = (EditText) findViewById(R.id.txtSearch);
		}
		return txtSearch;
	}


	public Button getBtnSearch() {
		if(btnSearch == null) {
			btnSearch = (Button) findViewById(R.id.btnSearch);
			btnSearch.setOnClickListener(new View.OnClickListener() {				
				@Override
				public void onClick(View v) {
					try {
						list.clear();
						currentIndex = 0;
						
						String searchBookName = txtSearch.getText().toString();						
						searchBookName = URLEncoder.encode(searchBookName, "utf-8");
						
						String strURL = "";
						strURL += "http://openapi.naver.com/search?";
						strURL += "key=ba402fa10538f8872a56deccf1488a07&";
						strURL += "target=book&";
						strURL += "query=" + searchBookName + "&";
						strURL += "display=5&";
						strURL += "start=1&";
						strURL += "sort=sim";
						URL url = new URL(strURL);
						HttpURLConnection conn = (HttpURLConnection) url.openConnection();
						conn.connect();
						
						if(conn.getResponseCode() == 200) {
							InputStream is = conn.getInputStream();
							
							XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
							XmlPullParser parser = factory.newPullParser();
							parser.setInput(is, "utf-8");
							
							boolean isItem = false;
							boolean isTitle = false;
							boolean isPublisher = false;
							boolean isPrice = false;
							boolean isAuthor = false;
							boolean isImage = false;	
							
							String title = null;
							String publisher = null;
							String price = null;
							String author = null;
							String image = null;
							
							int eventType = parser.getEventType();
							while(eventType != XmlPullParser.END_DOCUMENT) {
								if(eventType == XmlPullParser.START_TAG) {
									if(parser.getName().equals("item")) {
										isItem = true;
									} else if(isItem == true && parser.getName().equals("title")) {
										isTitle = true;
									} else if(isItem == true && parser.getName().equals("publisher")) {
										isPublisher = true;
									} else if(isItem == true && parser.getName().equals("price")) {
										isPrice = true;
									} else if(isItem == true && parser.getName().equals("author")) {
										isAuthor = true;
									} else if(isItem == true && parser.getName().equals("image")) {
										isImage = true;
									}  
								} else if(eventType == XmlPullParser.TEXT) {
									if(isTitle) {
										title = parser.getText();
										title = title.replace("<strong>", "");
										title = title.replace("</strong>", "");
										isTitle = false;
									} else if(isPublisher) {
										publisher = parser.getText();
										isPublisher = false;
									} else if(isPrice) {
										price = parser.getText();
										isPrice = false;
									} else if(isAuthor) {
										author = parser.getText();
										isAuthor = false;
									} else if(isImage) {
										image = parser.getText();
										isImage = false;
									}
								} else if(eventType == XmlPullParser.END_TAG) {
									if(parser.getName().equals("item")) {
										isItem = false;
										Book book = new Book();
										book.setTitle(title);
										book.setPublisher(publisher);
										book.setPrice(price);
										book.setAuthor(author);
										book.setImage(image);
										list.add(book);
									}
									
								}								
								eventType = parser.next();
							}
							
							is.close();
							
							//ù å�� ���÷���	
							if(list.size()>0) {
								displayBook(currentIndex);
							}
						}
						
						conn.disconnect();						
					} catch(Exception e) {
						e.printStackTrace();
					}
				}
			});
		}
		return btnSearch;
	}


	public EditText getTxtBookName() {
		if(txtBookName == null) {
			txtBookName = (EditText) findViewById(R.id.txtBookName);
		}
		return txtBookName;
	}


	public EditText getTxtBookPublisher() {
		if(txtBookPublisher == null) {
			txtBookPublisher = (EditText) findViewById(R.id.txtBookPublisher);
		}
		return txtBookPublisher;
	}


	public EditText getTxtBookPrice() {
		if(txtBookPrice == null) {
			txtBookPrice = (EditText) findViewById(R.id.txtBookPrice);
		}
		return txtBookPrice;
	}


	public EditText getTxtBookAuthor() {
		if(txtBookAuthor == null) {
			txtBookAuthor = (EditText) findViewById(R.id.txtBookAuthor);
		}
		return txtBookAuthor;
	}


	public ImageView getImgBook() {
		if(imgBook == null) {
			imgBook = (ImageView) findViewById(R.id.imgBook);
		}
		return imgBook;
	}


	public Button getBtnPrev() {
		if(btnPrev == null) {
			btnPrev = (Button) findViewById(R.id.btnPrev);
			btnPrev.setOnClickListener(new View.OnClickListener() {				
				@Override
				public void onClick(View v) {
					if(currentIndex > 0) {
						currentIndex--;
						displayBook(currentIndex);
					}
				}
			});
		}
		return btnPrev;
	}


	public Button getBtnNext() {
		if(btnNext == null) {
			btnNext = (Button) findViewById(R.id.btnNext);
			btnNext.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if(currentIndex<list.size()-1){
						currentIndex++;
						displayBook(currentIndex);
					}
				}
			});			
		}
		return btnNext;
	}
	
	private void displayBook(int index) {
		Book book = list.get(index);
		txtBookName.setText(book.getTitle());
		txtBookAuthor.setText(book.getAuthor());
		txtBookPrice.setText(book.getPrice());
		txtBookPublisher.setText(book.getPublisher());
		
		Bitmap bitmap = getBitmap(book.getImage());
		if(bitmap != null) {		
			imgBook.setImageBitmap(bitmap);
		}
	}
	
	private Bitmap getBitmap(String imageURL) {
		Bitmap bitmap = null;
		try {
			URL url = new URL(imageURL);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.connect();
			
			if(conn.getResponseCode() == 200) {
				InputStream is = conn.getInputStream();				
				bitmap = BitmapFactory.decodeStream(is);				
				is.close();
			}			
			conn.disconnect();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return bitmap;
	}
}



