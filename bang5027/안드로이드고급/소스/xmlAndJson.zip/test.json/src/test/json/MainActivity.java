package test.json;

import java.io.*;
import java.net.*;
import java.util.*;

import org.json.*;

import android.app.*;
import android.os.*;
import android.util.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends ListActivity {
	private List<Product> items;
	private BaseAdapter adapter;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getItems();
        setListAdapter(getAdapter());
    }

	public List<Product> getItems() {
		if(items == null) {
			items = new ArrayList<Product>();
			try {
				URL url = new URL("http://192.168.10.103:8080/test.xml.web/board/list_json.jsp");
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				if(conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
					InputStream is = conn.getInputStream();
					Reader reader = new InputStreamReader(is);
					BufferedReader br = new BufferedReader(reader);
					
					String strJson = "";
					String read = null;
					while((read = br.readLine()) != null) {
						strJson += read;
					}
				
					br.close(); reader.close(); is.close();
					
					JSONArray jsonArray = new JSONArray(strJson);
					for(int i=0; i<jsonArray.length(); i++) {
						JSONObject jsonObject = jsonArray.getJSONObject(i);
						Product product = new Product();
						product.setPno(jsonObject.getInt("pno"));
						product.setName(jsonObject.getString("name"));
						product.setPrice(jsonObject.getInt("price"));
						items.add(product);
					}
				}
				conn.disconnect();
			} catch (Exception e) {
				Log.d("test", e.toString());
				e.printStackTrace();
			}
		}
		return items;
	}

	public BaseAdapter getAdapter() {
		if(adapter == null) {
			adapter = new BaseAdapter() {
				@Override
				public int getCount() {
					return getItems().size();
				}

				@Override
				public Object getItem(int position) {
					return getItems().get(position);
				}

				@Override
				public long getItemId(int position) {
					return position;
				}

				@Override
				public View getView(int position, View convertView, ViewGroup parent) {
					if(convertView == null) {
						LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
						convertView = inflater.inflate(R.layout.list_item, parent, false);

						TextView item_pno = (TextView) convertView.findViewById(R.id.item_pno);
						item_pno.setText(String.valueOf(getItems().get(position).getPno()));
						
						TextView item_name = (TextView) convertView.findViewById(R.id.item_name);
						item_name.setText(getItems().get(position).getName());

						TextView item_price = (TextView) convertView.findViewById(R.id.item_price);
						item_price.setText(String.valueOf(getItems().get(position).getPrice()));
					}
					return convertView;
				}				
			};
		}
		return adapter;
	}
}
