package test.xml.xmlpullparser;

import java.io.*;
import java.net.*;
import java.util.*;

import org.xmlpull.v1.*;

import android.app.*;
import android.os.*;
import android.util.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends ListActivity {
	private List<Product> items;
	private BaseAdapter adapter;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getItems();
        setListAdapter(getAdapter());
    }

	public List<Product> getItems() {
		if(items == null) {
			items = new ArrayList<Product>();
			try {
				URL url = new URL("http://192.168.10.103:8080/test.xml.web/board/list.jsp");
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				if(conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
					InputStream is = conn.getInputStream();
					
					XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
					XmlPullParser parser = factory.newPullParser();
					parser.setInput(is, "euc-kr");
					
					Product product = null;
					boolean isName = false;
					boolean isPrice = false;
					int eventType = parser.getEventType();
					while(eventType != XmlPullParser.END_DOCUMENT) {
						if(eventType == XmlPullParser.START_TAG) {
							if(parser.getName().equals("product")) {
								product = new Product();
								product.setPno(Integer.parseInt(parser.getAttributeValue(null, "pno")));
							} else if(parser.getName().equals("name")) {
								isName = true;
							} else if(parser.getName().equals("price")) {
								isPrice = true;
							}
						} else if(eventType == XmlPullParser.TEXT) {
							if(isName) {
								product.setName(parser.getText());
								isName = false;
							} else if(isPrice) {
								product.setPrice(Integer.parseInt(parser.getText()));
								isPrice = false;
							}
						} else if(eventType == XmlPullParser.END_TAG) {
							if(parser.getName().equals("product")) {
								items.add(product);
							}
						}
						eventType = parser.next();
					}

					is.close();
				}
				conn.disconnect();
			} catch (Exception e) {
				Log.d("test", e.toString());
				e.printStackTrace();
			}
		}
		return items;
	}

	public BaseAdapter getAdapter() {
		if(adapter == null) {
			adapter = new BaseAdapter() {
				@Override
				public int getCount() {
					return getItems().size();
				}

				@Override
				public Object getItem(int position) {
					return getItems().get(position);
				}

				@Override
				public long getItemId(int position) {
					return position;
				}

				@Override
				public View getView(int position, View convertView, ViewGroup parent) {
					if(convertView == null) {
						LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
						convertView = inflater.inflate(R.layout.list_item, parent, false);

						TextView item_pno = (TextView) convertView.findViewById(R.id.item_pno);
						item_pno.setText(String.valueOf(getItems().get(position).getPno()));
						
						TextView item_name = (TextView) convertView.findViewById(R.id.item_name);
						item_name.setText(getItems().get(position).getName());

						TextView item_price = (TextView) convertView.findViewById(R.id.item_price);
						item_price.setText(String.valueOf(getItems().get(position).getPrice()));
					}
					return convertView;
				}				
			};
		}
		return adapter;
	}
}
