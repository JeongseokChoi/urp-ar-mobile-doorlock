package test.xml.sax;

import java.io.*;
import java.net.*;
import java.util.*;

import javax.xml.parsers.*;

import org.xml.sax.*;
import org.xml.sax.helpers.*;

import android.app.*;
import android.os.*;
import android.util.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends ListActivity {
	private List<Product> items;
	private BaseAdapter adapter;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getItems();
        setListAdapter(getAdapter());
    }

	public List<Product> getItems() {
		if(items == null) {
			items = new ArrayList<Product>();
			try {
				URL url = new URL("http://192.168.10.103:8080/test.xml.web/board/list.jsp");
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				if(conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
					InputStream is = conn.getInputStream();
					
					SAXParserFactory factory = SAXParserFactory.newInstance();
					SAXParser parser = factory.newSAXParser();
					Reader reader = new InputStreamReader(is, "euc-kr");
					InputSource inputSoruce = new InputSource(reader);
					parser.parse(inputSoruce, new DefaultHandler() {
						private Product product;
						private boolean isName, isPrice;
						@Override
						public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
							if(localName.equals("product")) {
								product = new Product();
								product.setPno(Integer.parseInt(attributes.getValue("pno")));
							} else if(localName.equals("name")) {
								isName = true;
							} else if(localName.equals("price")) {
								isPrice = true;
							}
						}
						@Override
						public void characters(char[] ch, int start, int length) throws SAXException {
							if(isName) {
								product.setName(new String(ch, start, length));
								isName = false;
							} else if(isPrice) {
								product.setPrice(Integer.parseInt(new String(ch, start, length)));
								isPrice = false;
							}
						}
						@Override
						public void endElement(String uri, String localName, String qName) throws SAXException {
							if(localName.equals("product")) {
								items.add(product);
							}
						}
					});

					is.close();
				}
				conn.disconnect();
			} catch (Exception e) {
				Log.d("test", e.toString());
				e.printStackTrace();
			}
		}
		return items;
	}

	public BaseAdapter getAdapter() {
		if(adapter == null) {
			adapter = new BaseAdapter() {
				@Override
				public int getCount() {
					return getItems().size();
				}

				@Override
				public Object getItem(int position) {
					return getItems().get(position);
				}

				@Override
				public long getItemId(int position) {
					return position;
				}

				@Override
				public View getView(int position, View convertView, ViewGroup parent) {
					if(convertView == null) {
						LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
						convertView = inflater.inflate(R.layout.list_item, parent, false);

						TextView item_pno = (TextView) convertView.findViewById(R.id.item_pno);
						item_pno.setText(String.valueOf(getItems().get(position).getPno()));
						
						TextView item_name = (TextView) convertView.findViewById(R.id.item_name);
						item_name.setText(getItems().get(position).getName());

						TextView item_price = (TextView) convertView.findViewById(R.id.item_price);
						item_price.setText(String.valueOf(getItems().get(position).getPrice()));
					}
					return convertView;
				}				
			};
		}
		return adapter;
	}
}
