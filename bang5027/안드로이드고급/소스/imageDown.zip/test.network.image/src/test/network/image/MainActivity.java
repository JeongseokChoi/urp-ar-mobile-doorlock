package test.network.image;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.app.Activity;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends Activity {
    private Button btnDirectView;
    private Button btnFileSaveView;
    private ImageView imageView;
    private Bitmap bitmap;
    private ProgressDialog progressDialog;
    private Handler handler;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        getBtnDirectView();
        getBtnFileSaveView();
        getImageView();
        getHandler();
    }

	public Button getBtnDirectView() {
		if(btnDirectView == null) {
			btnDirectView = (Button) findViewById(R.id.btnDirectView);
			btnDirectView.setOnClickListener(new Button.OnClickListener() {
				@Override
				public void onClick(View v) {
					getProgressDialog().show();
					Thread thread = new Thread() {
						@Override
						public void run() {
							try {
								URL url = new URL("http://192.168.10.103:8080/test.network.web/image/gingerdroid.png");
								HttpURLConnection conn = (HttpURLConnection)url.openConnection();
								if(conn != null) {
									if(conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
										InputStream is = conn.getInputStream();
										setBitmap(BitmapFactory.decodeStream(is));
										is.close();
									}
									conn.disconnect();
								}
								getHandler().sendEmptyMessage(0);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					};
					thread.start();
				}
			});
		}
		return btnDirectView;
	}

	public Button getBtnFileSaveView() {
		if(btnFileSaveView == null) {
			btnFileSaveView = (Button) findViewById(R.id.btnFileSaveView);
			btnFileSaveView.setOnClickListener(new Button.OnClickListener() {
				@Override
				public void onClick(View v) {
					getProgressDialog().show();
					Thread thread = new Thread() {
						@Override
						public void run() {
							try {
								String strURL = "http://192.168.10.103:8080/test.network.web/image/gingerdroid.png";	
								File fileData = Environment.getDataDirectory();
								String path = fileData.getAbsolutePath();
								path += "/data/" + getPackageName() + "/files/"; 
								if(new File(path).exists() == false) {
									new File(path).mkdir();
								}
								path += strURL.substring(strURL.lastIndexOf("/") + 1);	
								if(new File(path).exists() == false) {
									URL url = new URL(strURL);
									HttpURLConnection conn = (HttpURLConnection)url.openConnection();											
									if(conn != null) {
										if(conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
											InputStream is = conn.getInputStream();											
											FileOutputStream fos = new FileOutputStream(path);
											byte[] data = new byte[1024];
											int count = -1;
											while((count = is.read(data)) != -1) {
												fos.write(data, 0, count);
											}
											fos.close();
											is.close();
										}
										conn.disconnect();
										setBitmap(BitmapFactory.decodeFile(path));
									}
								}
								getHandler().sendEmptyMessage(0);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					};
					thread.start();
				}
			});
		}
		return btnFileSaveView;
	}

	public ImageView getImageView() {
		if(imageView == null) {
			imageView = (ImageView) findViewById(R.id.imageView);
		}
		return imageView;
	}

	public Bitmap getBitmap() {
		return bitmap;
	}

	public void setBitmap(Bitmap bitmap) {
		this.bitmap = bitmap;
	}
	
	public ProgressDialog getProgressDialog() {
		if(progressDialog == null) {
			progressDialog = new ProgressDialog(this);
			progressDialog.setTitle("�ٿ�ε�");
			progressDialog.setMessage("�̹��� �ٿ�ε� ��...");
			progressDialog.setCancelable(true);
		}
		return progressDialog;
	}	

	public Handler getHandler() {
		if(handler == null) {
			handler = new Handler() {
				@Override
				public void handleMessage(Message msg) {
					getProgressDialog().dismiss();
					progressDialog = null;
					getImageView().setImageBitmap(getBitmap());
				}
			};
		}
		return handler;
	}
}