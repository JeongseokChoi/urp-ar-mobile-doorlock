package hardware.sensor;

import hardware.sensor.acceleration.GetAccelerationActivity;
import hardware.sensor.acceleration.LadybugActivity;
import hardware.sensor.orientation.GetOrientationActivity1;
import hardware.sensor.orientation.GetOrientationActivity2;
import hardware.sensor.orientation.OrientationIndicatorActivity;
import hardware.sensor.proximity.AhhhActivity;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends Activity {	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);        
        findViewById(R.id.btnSensorInfo).setOnClickListener(onClickListener);
        findViewById(R.id.btnOrientation1).setOnClickListener(onClickListener);
        findViewById(R.id.btnOrientation2).setOnClickListener(onClickListener);
        findViewById(R.id.btnOrientationIndicator).setOnClickListener(onClickListener);
        findViewById(R.id.btnAcceleration).setOnClickListener(onClickListener);
        findViewById(R.id.btnLadybug).setOnClickListener(onClickListener);
        findViewById(R.id.btnProximity).setOnClickListener(onClickListener);
    }
    
	View.OnClickListener onClickListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			if(v.getId() == R.id.btnSensorInfo) {
				Intent intent = new Intent(MainActivity.this, SensorInfoActivity.class);
				startActivity(intent);
			} else if(v.getId() == R.id.btnOrientation1) {
				Intent intent = new Intent(MainActivity.this, GetOrientationActivity1.class);
				startActivity(intent);
			} else if(v.getId() == R.id.btnOrientation2) {
				Intent intent = new Intent(MainActivity.this, GetOrientationActivity2.class);
				startActivity(intent);
			} else if(v.getId() == R.id.btnOrientation2) {
				Intent intent = new Intent(MainActivity.this, GetOrientationActivity2.class);
				startActivity(intent);
			} else if(v.getId() == R.id.btnOrientationIndicator) {
				Intent intent = new Intent(MainActivity.this, OrientationIndicatorActivity.class);
				startActivity(intent);
			} else if(v.getId() == R.id.btnAcceleration) {
				Intent intent = new Intent(MainActivity.this, GetAccelerationActivity.class);
				startActivity(intent);
			} else if(v.getId() == R.id.btnLadybug) {
				Intent intent = new Intent(MainActivity.this, LadybugActivity.class);
				startActivity(intent);
			} else if(v.getId() == R.id.btnProximity) {
				Intent intent = new Intent(MainActivity.this, AhhhActivity.class);
				startActivity(intent);
			} else if(v.getId() == R.id.btnTest) {
				Intent intent = new Intent(MainActivity.this, TestActivity.class);
				startActivity(intent);
			}
		}
	};
}