package hardware.sensor.acceleration;

import hardware.sensor.R;
import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

public class GetAccelerationActivity extends Activity {
	private TextView txtAccX, txtAccY, txtAccZ;
	private SensorManager sensorManager;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.get_acceleration);
		
		txtAccX = (TextView) findViewById(R.id.txtAccX);
		txtAccY = (TextView) findViewById(R.id.txtAccY);
		txtAccZ = (TextView) findViewById(R.id.txtAccZ);
		
		sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		sensorManager.registerListener(
				sensorEventListener, 
				sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
				SensorManager.SENSOR_DELAY_UI);	
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		sensorManager.unregisterListener(sensorEventListener);
	}	
	
	private SensorEventListener sensorEventListener = new SensorEventListener() {
		@Override
		public void onAccuracyChanged(Sensor sensor, int accuracy) {
		}
		@Override
		public void onSensorChanged(SensorEvent event) {
			float accX = ((int)event.values[0]*100)/100.0f;  
			float accY = ((int)event.values[1]*100)/100.0f;  
			float accZ = ((int)event.values[2]*100)/100.0f;
			
			txtAccX.setText("X�� ���ӵ�: " + accX + " m/s2");
			txtAccY.setText("Y�� ���ӵ�: " + accY + " m/s2");
			txtAccZ.setText("Z�� ���ӵ�: " + accZ + " m/s2");
		}
	};
}
