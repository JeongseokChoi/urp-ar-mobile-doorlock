package chap15.p801;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity extends Activity {
    private EditText txtSearch, txtWeather, txtTemperature;
    private Button btnSearch;
    private ImageView imgIcon;
    private List<Local> list = new ArrayList();
    private int currIndex;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        getTxtSearch();
        getBtnSearch();
        getTxtWeather();
        getTxtTemperature();
        getImgIcon();
    }

	public EditText getTxtSearch() {
		if(txtSearch == null){
			txtSearch = (EditText)findViewById(R.id.txtSearch);
		}
		return txtSearch;
	}

	public EditText getTxtWeather() {
		if(txtWeather == null){
			txtWeather = (EditText)findViewById(R.id.txtWeather);
		}
		return txtWeather;
	}

	public EditText getTxtTemperature() {
		if(txtTemperature == null){
			txtTemperature = (EditText)findViewById(R.id.txtTemperature);
		}
		return txtTemperature;
	}

	public Button getBtnSearch() {
		if(btnSearch == null){
			btnSearch = (Button)findViewById(R.id.btnSearch);
			btnSearch.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					try {
						list.clear();
						currIndex = 0;
						
						String strURL = "http://www.kma.go.kr/XML/weather/sfc_web_map.xml";
						
						URL url = new URL(strURL);
						HttpURLConnection conn = (HttpURLConnection)url.openConnection();
						conn.connect();
						
						if(conn.getResponseCode() == 200){
							InputStream is = conn.getInputStream();
							
							XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
							XmlPullParser parser = factory.newPullParser();
							parser.setInput(is,"utf-8");
							int eventType = parser.getEventType();
							
							String icon = null;
							String desc = null;
							String ta = null;
							String name = null;
							while(eventType != XmlPullParser.END_DOCUMENT){
								if(eventType == XmlPullParser.START_TAG){
									if(parser.getName().equals("local")){
										icon = parser.getAttributeValue(null,"icon");
										desc = parser.getAttributeValue(null,"desc");
										ta = parser.getAttributeValue(null,"ta");
									}
								}else if(eventType == XmlPullParser.TEXT){
									name = parser.getText();
								}else if(eventType == XmlPullParser.END_TAG){
									if(parser.getName().equals("local")){
										Local local = new Local();
										local.setIcon(icon);
										local.setDesc(desc);
										local.setTa(ta);
										local.setName(name);
										list.add(local);
									}
								}
								eventType = parser.next();
							}
							
							is.close();
							
							//ù å�� ���÷���
							if(list.size()>0){
								displayWeather(currIndex);
							}else{
								
							}
						}
						
						conn.disconnect();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}
		return btnSearch;
	}

	public ImageView getImgIcon() {
		if(imgIcon == null){
			imgIcon = (ImageView)findViewById(R.id.imgIcon);
		}
		return imgIcon;
	}
	
	private void displayWeather(int index){
		for(Local local : list){
			if(txtSearch.getText().toString().equals(local.getName())){
				txtWeather.setText(local.getDesc());
				txtTemperature.setText(local.getTa());
				if(local.getIcon().equals("01")){
					imgIcon.setImageResource(R.drawable.icon1);
				}else if(local.getIcon().equals("02")){
					imgIcon.setImageResource(R.drawable.icon2);
				}else if(local.getIcon().equals("03")){
					imgIcon.setImageResource(R.drawable.icon3);
				}else{
					
				}
			}else{
				
			}
		}	
	}
}