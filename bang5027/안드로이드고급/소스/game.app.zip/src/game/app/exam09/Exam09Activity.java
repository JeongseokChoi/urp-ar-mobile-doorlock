package game.app.exam09;

import android.app.Activity;
import android.os.Bundle;

public class Exam09Activity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		GameView gameView = new GameView(this);
		setContentView(gameView);
	}
}
