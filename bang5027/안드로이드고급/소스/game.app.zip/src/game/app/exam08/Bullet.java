package game.app.exam08;

import java.util.Timer;
import java.util.TimerTask;

import game.app.R;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;

public class Bullet {
	//�ʵ�
	private GameView gameView;
	private static Bitmap[] bitmaps;
	private Rect rect;
	private int index;
	private Timer timer;	
	private int direction;
	//������
	public Bullet(GameView gameView, Rect actorRect, int direction) {
		this.gameView = gameView;
		this.direction = direction;
		//��Ʈ�� ���
		Resources resources = gameView.getResources();
		if(bitmaps == null) {
			bitmaps = new Bitmap[] {
				BitmapFactory.decodeResource(resources, R.drawable.bullet_01_01)
			};
		}
		//�ʱ� ����� ���� ����
		rect = new Rect(
				actorRect.left + actorRect.width()/2 - 5,
				actorRect.top + actorRect.height()/2 - 5,
				actorRect.left + actorRect.width()/2 - 5 + bitmaps[0].getWidth(),
				actorRect.top + actorRect.height()/2 - 5 + bitmaps[0].getHeight()
		);
		//Ÿ�̸� ����
		timer = new Timer();
		timer.schedule(timerTask, 0, 100);
	}
	//��Ʈ�� �����
	public void draw(Canvas canvas) {
		canvas.drawBitmap(bitmaps[index], 
				rect.left+gameView.background.rect.left, 
				rect.top+gameView.background.rect.top, 
				null);
	}
	//�̵� �ִϸ��̼�
	private TimerTask timerTask = new TimerTask() {
		@Override
		public void run() {
			//���������� �̵�
			if(direction == Arrow.RIGHT) {
				if((rect.right+gameView.background.rect.left) < gameView.getWidth()) {
					rect.left += 8;
					rect.right += 8;
				} else {
					destroy();
				}
			} 
			//�������� �̵�
			else if(direction == Arrow.LEFT) {
				if((rect.left+gameView.background.rect.left) > 0) {
					rect.left -= 8;
					rect.right -= 8;
				} else {
					destroy();
				}
			} 
			//�Ʒ������� �̵�
			else if(direction == Arrow.DOWN) {
				if((rect.bottom+gameView.background.rect.top) < gameView.getHeight()) {
					rect.top += 8;
					rect.bottom += 8;
				} else {
					destroy();
				}
			} 
			//���� �̵�
			else if(direction == Arrow.UP) {
				if((rect.top+gameView.background.rect.top) > 0) {
					rect.top -= 8;
					rect.bottom -= 8;
				} else {
					destroy();
				}
			}
		}
	};	

	//�ڽ��� �ı�
	private void destroy() {
		timer.cancel();
		timer.purge();
		gameView.bulletPool.bullets.remove(Bullet.this);
	}
}
