package game.app.exam07;

import android.app.Activity;
import android.os.Bundle;

public class Exam07Activity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		GameView gameView = new GameView(this);
		setContentView(gameView);
	}
}
