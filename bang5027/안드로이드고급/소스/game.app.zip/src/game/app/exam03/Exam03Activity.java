package game.app.exam03;

import android.app.Activity;
import android.os.Bundle;

public class Exam03Activity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		GameView gameView = new GameView(this);
		setContentView(gameView);
	}
}
