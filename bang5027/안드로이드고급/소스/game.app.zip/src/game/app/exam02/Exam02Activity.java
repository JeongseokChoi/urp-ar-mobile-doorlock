package game.app.exam02;

import android.app.Activity;
import android.os.Bundle;

public class Exam02Activity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		GameView gameView = new GameView(this);
		setContentView(gameView);
	}
}
