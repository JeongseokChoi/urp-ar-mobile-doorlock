package game.app.exam06;

import game.app.R;

import java.util.Timer;
import java.util.TimerTask;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;

public class Fire {
	//�ʵ�
	private GameView gameView;
	private Bitmap[] bitmaps;
	private Rect rect;
	private int index;
	private Timer timer;
	//������	
	public Fire(GameView gameView) {
		this.gameView = gameView;
		//��Ʈ�� ���
		Resources resources = gameView.getResources();
		bitmaps = new Bitmap[] {
			BitmapFactory.decodeResource(resources, R.drawable.fire_01_01),
			BitmapFactory.decodeResource(resources, R.drawable.fire_01_02),
			BitmapFactory.decodeResource(resources, R.drawable.fire_01_03),
		};
		//�ʱ� ����� ���� ����
		rect = new Rect(320, 192, 320+bitmaps[0].getWidth(),192+bitmaps[0].getHeight());
		//Ÿ�̸� ����
		timer = new Timer();
		timer.schedule(timerTask, 0, 200);
	}
	//��Ʈ�� �����
	public void draw(Canvas canvas) {	
		canvas.drawBitmap(bitmaps[index], 
				rect.left+gameView.background.rect.left, 
				rect.top+gameView.background.rect.top, 
				null);
	}	
	//�Ҳ� �ִϸ��̼�
	private TimerTask timerTask = new TimerTask() {
		@Override
		public void run() {
			index++;
			if(index == bitmaps.length) {
				index = 0;
			}
		}
	};
	//�ڽ��� �ı�
	public void destory() {
		timer.cancel();
		timer.purge();
	}
}
