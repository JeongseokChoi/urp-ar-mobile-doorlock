package game.app.exam04;

import android.app.Activity;
import android.os.Bundle;

public class Exam04Activity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		GameView gameView = new GameView(this);
		setContentView(gameView);
	}
}
