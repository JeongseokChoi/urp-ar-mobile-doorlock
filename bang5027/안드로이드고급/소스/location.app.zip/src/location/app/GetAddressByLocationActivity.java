package location.app;

import java.io.IOException;
import java.util.List;
import java.util.StringTokenizer;

import android.app.Activity;
import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;

public class GetAddressByLocationActivity extends Activity {
	private TextView txtInfo;
	private LocationManager locationManager;	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.txtinfo);
		txtInfo = (TextView) findViewById(R.id.txtInfo);
		locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		locationManager.requestLocationUpdates(
				LocationManager.GPS_PROVIDER, 0, 0, locationListener);
	}
	
	private LocationListener locationListener = new LocationListener() {
		public void onLocationChanged(Location location) {
			locationManager.removeUpdates(locationListener);
			double latitude =  location.getLatitude();
			double longitude = location.getLongitude();
			getAddress(latitude, longitude);
		}
		public void onProviderDisabled(String provider) {}
		public void onProviderEnabled(String provider) {}
		public void onStatusChanged(String provider, int status, Bundle extras) {}
	};
	
	private void getAddress(final double latitude, final double longitude) {
		Thread thread = new Thread() {
			@Override
			public void run() {
				Geocoder geocoder = new Geocoder(GetAddressByLocationActivity.this);
				List<Address> addressList = null;
				try {
					addressList = geocoder.getFromLocation(latitude, longitude, 1);
				} catch(IOException e) {
					e.printStackTrace();
				}
				Message msg = Message.obtain();
				msg.obj = addressList;
				handler.sendMessage(msg);
			}
		};
		thread.start();
	}
	
	private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			List<Address> addressList = (List<Address>)msg.obj;
			if(addressList != null && addressList.size() != 0) {
				Address address = addressList.get(0);
				String fullAddress = "";
				int maxAddressLineIndex = address.getMaxAddressLineIndex();
				for(int i=0; i<=maxAddressLineIndex; i++) {
					fullAddress += address.getAddressLine(i);
				}
				txtInfo.append("��ü�ּ�: " + fullAddress + "\n");				
				txtInfo.append("�����̸�: " + address.getCountryName() + "\n");	
				txtInfo.append("�����ڵ�: " + address.getCountryCode() + "\n");	
				txtInfo.append("��: " + address.getAdminArea() + "\n");			
				txtInfo.append("��: " + address.getLocality() + "\n");
				txtInfo.append("��: " + getGoo(fullAddress) + "\n");
				txtInfo.append("��,��,��,��: " + address.getThoroughfare() + "\n");
				txtInfo.append("����: " + address.getFeatureName() + "\n");		
				txtInfo.append("������ȣ: " + address.getPostalCode() + "\n");
			} else {
				txtInfo.append("�ּҸ� ã�� ���߽��ϴ�.");
			}
		}
	};
	
	private String getGoo(String fullAddress) {
		StringTokenizer st = new StringTokenizer(fullAddress, " ");
		while(st.hasMoreTokens()) {
			String token = st.nextToken();
			if(token.substring(token.length()-1).equals("��")) {
				return token;
			}
		}
		return "";
	}
}




























