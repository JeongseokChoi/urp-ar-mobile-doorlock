package location.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends Activity implements View.OnClickListener {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		findViewById(R.id.btnGetLocationProviderInfo).setOnClickListener(this);
		findViewById(R.id.btnSelectLocationProviderByUser).setOnClickListener(this);
		findViewById(R.id.btnSelectBestLocationProvider).setOnClickListener(this);
		findViewById(R.id.btnGetLocationByLocationListener).setOnClickListener(this);
		findViewById(R.id.btnGetLocationByPendingIntent).setOnClickListener(this);
		findViewById(R.id.btnGetGPSInfo).setOnClickListener(this);
		findViewById(R.id.btnProximityAlert).setOnClickListener(this);
		findViewById(R.id.btnAddressByLocation).setOnClickListener(this);
		findViewById(R.id.btnLocationByAddress).setOnClickListener(this);
		findViewById(R.id.btnGoogleMaps).setOnClickListener(this);
		findViewById(R.id.btnMapView).setOnClickListener(this);
		findViewById(R.id.btnMapViewWithWidget).setOnClickListener(this);
		findViewById(R.id.btnOverlay).setOnClickListener(this);
		findViewById(R.id.btnMultiOverlay).setOnClickListener(this);
		findViewById(R.id.btnMyLocationOverlay).setOnClickListener(this);
		findViewById(R.id.btnItemizedOverlay).setOnClickListener(this);
	}

	public void onClick(View v) {
		Intent intent = null;
		switch(v.getId()) {
			case R.id.btnGetLocationProviderInfo:
				intent = new Intent(MainActivity.this, GetLocationProviderInfoActivity.class);
				break;
			case R.id.btnSelectLocationProviderByUser:
				intent = new Intent(MainActivity.this, SelectLocationProviderByUser.class);
				break;
			case R.id.btnSelectBestLocationProvider:
				intent = new Intent(MainActivity.this, SelectBestLocationProviderActivity.class);
				break;	
			case R.id.btnGetLocationByLocationListener:
				intent = new Intent(MainActivity.this, GetLocationByLocationListenerActivity.class);
				break;	
			case R.id.btnGetLocationByPendingIntent:
				intent = new Intent(MainActivity.this, GetLocationByPendingIntentActivity.class);
				break;
			case R.id.btnGetGPSInfo:
				intent = new Intent(MainActivity.this, GetGPSInfoActivity.class);
				break;	
			case R.id.btnProximityAlert:
				intent = new Intent(MainActivity.this, ProximityAlertActivity.class);
				break;	
			case R.id.btnAddressByLocation:
				intent = new Intent(MainActivity.this, GetAddressByLocationActivity.class);
				break;
			case R.id.btnLocationByAddress:
				intent = new Intent(MainActivity.this, GetLocationByAddressActivity.class);
				break;
			case R.id.btnGoogleMaps:
				intent = new Intent(MainActivity.this, GoogleMapsActivity.class);
				break;
			case R.id.btnMapView:
				intent = new Intent(MainActivity.this, MapViewActivity.class);
				break;	
			case R.id.btnMapViewWithWidget:
				intent = new Intent(MainActivity.this, MapViewWithWidgetActivity.class);
				break;	
			case R.id.btnOverlay:
				intent = new Intent(MainActivity.this, OverlayActivity.class);
				break;
			case R.id.btnMultiOverlay:
				intent = new Intent(MainActivity.this, MultiOverlayActivity.class);
				break;	
			case R.id.btnMyLocationOverlay:
				intent = new Intent(MainActivity.this, MyLocationOverlayActivity.class);
				break;	
			case R.id.btnItemizedOverlay:
				intent = new Intent(MainActivity.this, ItemizedOverlayActivity.class);
				break;	
		}
		startActivity(intent);
	}
}