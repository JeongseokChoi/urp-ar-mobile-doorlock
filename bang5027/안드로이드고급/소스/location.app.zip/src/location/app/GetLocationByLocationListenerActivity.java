package location.app;

import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.TextView;

public class GetLocationByLocationListenerActivity extends Activity {
	private TextView txtInfo;
	private LocationManager locationManager;	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.txtinfo);
		txtInfo = (TextView) findViewById(R.id.txtInfo);
		locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);		
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		locationManager.requestLocationUpdates(
				LocationManager.GPS_PROVIDER, 1000, 10, locationListener);
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		locationManager.removeUpdates(locationListener);
	}
	
	private LocationListener locationListener = new LocationListener() {
		public void onLocationChanged(Location location) {
			txtInfo.append("����: " + location.getLatitude() + "\n");
			txtInfo.append("�浵: " + location.getLongitude() + "\n\n");
		}
		public void onProviderDisabled(String provider) {}
		public void onProviderEnabled(String provider) {}
		public void onStatusChanged(String provider, int status, Bundle extras) {}
	};	
}
