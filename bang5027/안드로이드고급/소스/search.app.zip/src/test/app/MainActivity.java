package test.app;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
		TextView textView = (TextView) findViewById(R.id.textView);		
		
		List<Contents> list = getContentsList();
		for(int i=0; i<list.size(); i++) {
			Contents contents = list.get(i);
			textView.append(contents.name + "\n");
			textView.append(contents.address + "\n");
			textView.append(contents.latitude + "\n");
			textView.append(contents.longitude + "\n");
			
			contents = ConvertCoord.fromKatecToWGS84(contents);
			
			textView.append(contents.latitude + "\n");
			textView.append(contents.longitude + "\n");
			
			textView.append("\n");
		}
    }
    
    
    public List<Contents> getContentsList() {
		List<Contents> list = new ArrayList<Contents>();
		try {
			String query = "������ ����";
			query = URLEncoder.encode(query, "utf-8");
			
	        URL url = new URL("http://openapi.naver.com/search?key=bf5a83c7581616f45d6b992135a38f18&query=" + query + "&target=local&start=1&display=10");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			if(conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
				InputStream is = conn.getInputStream();
				
				XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
				XmlPullParser parser = factory.newPullParser();
				parser.setInput(is, "utf-8");
				
				Contents contents = null;
				boolean isItem = false;
				boolean isTitle = false;
				boolean isAddress = false;
				boolean isLatitude = false;
				boolean isLongitude = false;
				int eventType = parser.getEventType();
				while(eventType != XmlPullParser.END_DOCUMENT) {
					if(eventType == XmlPullParser.START_TAG) {
						if(parser.getName().equals("item")) {
							contents = new Contents();
							isItem = true;
						} else if(isItem && parser.getName().equals("title")) {
							isTitle = true;
						} else if(parser.getName().equals("address")) {
							isAddress = true;
						} else if(parser.getName().equals("mapx")) {
							isLatitude = true;
						} else if(parser.getName().equals("mapy")) {
							isLongitude = true;
						} 
					} else if(eventType == XmlPullParser.TEXT) {
						if(isTitle) {
							contents.name = parser.getText();
							isTitle = false;
						} else if(isAddress) {
							contents.address = parser.getText();
							isAddress = false;
						} else if(isLatitude) {
							contents.latitude = Double.parseDouble(parser.getText());
							isLatitude = false;
						} else if(isLongitude) {
							contents.longitude = Double.parseDouble(parser.getText());
							isLongitude = false;
						}
					} else if(eventType == XmlPullParser.END_TAG) {
						if(parser.getName().equals("item")) {
							list.add(contents);
							isItem = false;
						} 
					}
					eventType = parser.next();
				}
				
				is.close();
			}
			conn.disconnect();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
    
    public Contents changeCoord(Contents contents) {
    	return contents;
	}
    
}