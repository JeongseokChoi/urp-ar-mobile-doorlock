package network.app.exam05;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import network.app.R;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;

public class Exam05Activity extends Activity {	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.exam05);		
		
		ImageView imageView = (ImageView) findViewById(R.id.imageView);		
		
		Bitmap bitmap = getImageDownload();
		imageView.setImageBitmap(bitmap);		
	}
	
	public Bitmap getImageDownload() {
		Bitmap bitmap = null;
		try {
			URL url = new URL("http://222.235.48.62:8080/network.web/image.png");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			if(conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
				InputStream is = conn.getInputStream();
				bitmap = BitmapFactory.decodeStream(is);
				is.close();
			}
			conn.disconnect();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bitmap;
	}	
}
