package network.app.exam06;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import network.app.R;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ImageView;

public class Exam06Activity extends Activity {	
	private ImageView imageView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.exam06);		
		
		imageView = (ImageView) findViewById(R.id.imageView);		
		
		thread.start();		
	}
	
	private Thread thread = new Thread() {
		@Override
		public void run() {
			try {
				URL url = new URL("http://222.235.48.62:8080/network.web/image.png");
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				if(conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
					InputStream is = conn.getInputStream();
					Bitmap bitmap = BitmapFactory.decodeStream(is);
					Message msg = Message.obtain();
					msg.obj = bitmap;
					handler.sendMessage(msg);
					is.close();
				}
				conn.disconnect();
			} catch (Exception e) {
				e.printStackTrace();
			}
		};
	};
	
	private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			Bitmap bitmap = (Bitmap) msg.obj;
			imageView.setImageBitmap(bitmap);
		}
	};
}
