package ar.app.exam06;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import ar.app.R;

public class Exam06Activity extends Activity {
	//�ʵ�
	private ContentsView contentsView;
	private SensorManager sensorManager;
	private int azimuth;	
	//������ ����
    @Override
	protected void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.exam06);
    	contentsView = (ContentsView) findViewById(R.id.contentsView);
    }	
    
    //���׶���� ����
    @Override
    protected void onResume() {
    	super.onResume();
    	//����� ���� ��ġ�� ���Ƿ� ��:GPS�� �̿��ϴ� �ڵ�� ������ ��
    	contentsView.addContents(37.495509, 127.025468, null);
    	
    	sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		sensorManager.registerListener(
				sensorEventListener, 
				sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION), 
				SensorManager.SENSOR_DELAY_UI);	
    }
    //�Ͻ������� ����
	@Override
	protected void onPause() {
		super.onPause();
		sensorManager.unregisterListener(sensorEventListener);
	}	
	//���� �̺�Ʈ ó��
	private SensorEventListener sensorEventListener = new SensorEventListener() {
		@Override
		public void onAccuracyChanged(Sensor sensor, int accuracy) {
		}
		@Override
		public void onSensorChanged(SensorEvent event) {
			azimuth = (int) event.values[0];
			contentsView.changeContentsRect(azimuth);
		}
	};
}
