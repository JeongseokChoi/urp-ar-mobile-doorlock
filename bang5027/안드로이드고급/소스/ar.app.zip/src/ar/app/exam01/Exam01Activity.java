package ar.app.exam01;

import ar.app.R;
import android.app.Activity;
import android.os.Bundle;

public class Exam01Activity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		setContentView(R.layout.exam01);
    }
}